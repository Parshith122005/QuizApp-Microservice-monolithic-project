
package com.quiz.quizeApp.controller;

import com.quiz.quizeApp.model.Questions;
import com.quiz.quizeApp.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class QuestionController {
@Autowired
private QuestionService questionService;
    @GetMapping("/")
    public ResponseEntity<List<Questions>> getAllQuestions() {
        return questionService.getAllQuestion();
    }

    @GetMapping("/{topic}")
    public List<Questions> getQuestionsByTopic(@PathVariable String topic){
        return questionService.getQuestionsBytpic(topic);
    }

    @PostMapping("/add")
    public ResponseEntity<Questions> addQuestion(@RequestBody Questions questions){
        return questionService.addQuestion(questions);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteQuestionById(@PathVariable Integer id){
        return questionService.deleteQuestionById(id);
    }
}

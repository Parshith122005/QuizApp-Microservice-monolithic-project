package com.quiz.quizeApp.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Quiz {
    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer numQ;
   private String title;
   @ManyToMany
   private List<Questions> questions;

}

package com.quiz.quizeApp.dao;

import com.quiz.quizeApp.model.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizDao extends JpaRepository<Quiz, Integer> {
}

package com.quiz.quizeApp.model;

import lombok.Data;

@Data
public class Response {
    Integer id;
    String response;
}

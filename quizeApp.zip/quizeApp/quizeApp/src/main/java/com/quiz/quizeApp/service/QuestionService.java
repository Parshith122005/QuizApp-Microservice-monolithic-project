package com.quiz.quizeApp.service;

import com.quiz.quizeApp.dao.QuestionDao;
import com.quiz.quizeApp.model.Questions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

@Autowired
    QuestionDao questionDao;
    public ResponseEntity<List<Questions>> getAllQuestion() {
        try{
        return new ResponseEntity<>(questionDao.findAll(), HttpStatus.OK);
    }catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    public List<Questions> getQuestionsBytpic(String topic) {
        return questionDao.getQuestionByTopic(topic);
    }

    public ResponseEntity<Questions> addQuestion(Questions questions) {
        try{
            questionDao.save(questions);
            return new ResponseEntity<>(questions,HttpStatus.CREATED);
        }catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

    }

    public String deleteQuestionById( Integer id) {
        questionDao.deleteById(id);
     return "Question has been deleted";

    }


}

package com.quiz.quizeApp.service;

import com.quiz.quizeApp.dao.QuestionDao;
import com.quiz.quizeApp.dao.QuizDao;
import com.quiz.quizeApp.model.QuestionWrapper;
import com.quiz.quizeApp.model.Questions;
import com.quiz.quizeApp.model.Quiz;
import com.quiz.quizeApp.model.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class QuizService {
    @Autowired
    QuizDao quizDao;
    @Autowired
    QuestionDao questionDao;
    public ResponseEntity<String> setQuiz(String topic, Integer numQ, String title) {
        List<Questions> questions=questionDao.SetQuestionInQuiz(topic,numQ);
        Quiz quiz=new Quiz();
        quiz.setTitle(title);
        quiz.setQuestions(questions);
        quizDao.save(quiz);
        return new ResponseEntity<>("Success", HttpStatus.CREATED);

    }

    public ResponseEntity<List<QuestionWrapper>> getQuize(Integer id) {
        Optional<Quiz> quiz=quizDao.findById(id);
        List<Questions> questionsFromDb=quiz.get().getQuestions();
        List<QuestionWrapper> questionWrappers=new ArrayList<>();
        for(Questions q : questionsFromDb){
            QuestionWrapper qw =new QuestionWrapper(q.getId(),q.getQuestionText(),q.getOptionA(),q.getOptionB(),q.getOptionC(),q.getOptionD());
            questionWrappers.add(qw);
        }
        return new ResponseEntity<>(questionWrappers,HttpStatus.OK);
    }

    public ResponseEntity<String> getResult(Integer id, List<Response> response) {
        Optional<Quiz> quiz =quizDao.findById(id);
        List<Questions> questions=quiz.get().getQuestions();
        int result=0;
        int i=0;
for(Response res:response){
    if(res.getResponse().equals(questions.get(i).getCorrectOption()))
        result++;
    i++;
}
return new ResponseEntity<>("Result "+ result + "/" +i ,HttpStatus.OK);
    }
}

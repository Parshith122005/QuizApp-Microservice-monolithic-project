package com.quiz.quizeApp.controller;

import com.quiz.quizeApp.model.QuestionWrapper;
import com.quiz.quizeApp.model.Response;
import com.quiz.quizeApp.service.QuizService;
import jakarta.persistence.GeneratedValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuizController {
    @Autowired
    QuizService quizService;

    @PostMapping("/create")
    public ResponseEntity<String> QuizController(@RequestParam String topic, @RequestParam Integer numQ,@RequestParam String title){
        return quizService.setQuiz(topic,numQ,title);

    }
@GetMapping("/get/{id}")
    public ResponseEntity<List<QuestionWrapper>> GetQuizController(@PathVariable Integer id){
        return quizService.getQuize(id);
    }
    @PostMapping("/submit/{id}")
    public ResponseEntity<String> CalculateResul   (@PathVariable Integer id,@RequestBody List<Response> response){
        return quizService.getResult(id,response);
    }
}

package com.quiz.quizeApp.dao;

import com.quiz.quizeApp.model.Questions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionDao extends JpaRepository<Questions, Integer> {

    List<Questions> getQuestionByTopic(String topic);

@Query(value = "SELECT * from Questions q where q.topic= :topic order by random() limit :numQ",nativeQuery = true)
    List<Questions> SetQuestionInQuiz(String topic, Integer numQ);
}
